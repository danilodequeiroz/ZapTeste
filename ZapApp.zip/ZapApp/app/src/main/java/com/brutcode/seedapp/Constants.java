package com.brutcode.seedapp;

/**
 * Created by Danilo on 05/07/2016.
 */
public class Constants {

    public static final String ZAPTESTAPIURI = "http://demo4573903.mockable.io";


        public static final String PROGRESS_DIALOG_STATE_BUNDLE = "wasProgShowing";
        public static final String SEARCH_DIALOG_STATE_BUNDLE = "wasSearchShowing";



        public static final String CONTENT_BUNDLE_PHOTO_GALLERY = "GL_BDL";
        public static final String CONTENT_BUNDLE_PHOTO_SELECTED = "GLI_BDL";
        public static final String CONTENT_BUNDLE = "C_BDL";
        public static final String CONTENT_STATE_BUNDLE = "CST_BDL";



}
