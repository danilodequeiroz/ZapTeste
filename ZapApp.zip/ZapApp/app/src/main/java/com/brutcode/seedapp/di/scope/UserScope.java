package com.brutcode.seedapp.di.scope;

/**
 * Created by Danilo on 04/07/2016.
 */
import javax.inject.Scope;

@Scope
public @interface UserScope {
}
