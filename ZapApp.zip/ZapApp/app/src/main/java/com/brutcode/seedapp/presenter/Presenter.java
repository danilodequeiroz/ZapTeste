package com.brutcode.seedapp.presenter;

/**
 * Created by Danilo on 06/07/2016.
 */
public interface Presenter<T> {
    void setView(T view);
}
